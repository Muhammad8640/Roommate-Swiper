
import { useState } from "react";
import { supabase } from "./supabase";
import "./App.css";

function App() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  async function testBackend() {
    try {
      setMessage("Checking backend...");

      const result = await checkBackend();

      setMessage(`Backend connected! Status: ${result.data.status}`);
    } catch (error) {
      setMessage(
        "Could not connect to the backend. Make sure it is running."
      );
      console.error("Backend connection error:", error);
    }
  }

  async function signIn(event) {
    event.preventDefault();
    setMessage("");
    setLoading(true);

    const normalizedEmail = email.trim().toLowerCase();

    if (!normalizedEmail.includes("@gmu.edu")) {
      setMessage("Please use a GMU email address containing @gmu.edu.");
      setLoading(false);
      return;
    }

    setMessage("GMU email format accepted! You can continue.");
    setLoading(false);
  }

  return (
    <main className="auth-page">
      <section className="auth-card">
        <h1>Roommate Swiper</h1>
        <p>Find your next roommate, starting with your school email.</p>

        <form onSubmit={signIn}>
          <label htmlFor="email">School email</label>

          <input
            id="email"
            type="email"
            placeholder="you@gmu.edu"
            value={email}
            onChange={(event) => {
              setEmail(event.target.value);
              setMessage("");
            }}
            required
          />

          <button type="submit" disabled={loading}>
            {loading ? "Checking email..." : "Continue"}
          </button>
        </form>

        {message && <p role="status">{message}</p>}
      </section>
    </main>
  );
}

export default App;
